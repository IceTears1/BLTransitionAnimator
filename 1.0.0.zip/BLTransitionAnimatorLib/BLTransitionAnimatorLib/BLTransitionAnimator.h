//
//  BLTransitionAnimator.h
//  翻页效果
//
//  Created by 冰泪 on 2017/6/19.
//  Copyright © 2017年 冰泪. All rights reserved.
//

#ifndef BLTransitionAnimator_h
#define BLTransitionAnimator_h

//#import "BLPresentTransitionAnimator.h"//模态转场
//#import "BLPushTransitionAnimator.h"  //push转场
#import "UINavigationController+BLPushTrasition.h"
#import "UIViewController+BLPresentTrasition.h"
#import "BLTabBarTransitionAnimator.h"  //tabbar转场

#import "BLTransitionInteraction.h" //手势处理


#import "BLTrasitionAnimatorConfig.h"



#endif /* BLTransitionAnimator_h */

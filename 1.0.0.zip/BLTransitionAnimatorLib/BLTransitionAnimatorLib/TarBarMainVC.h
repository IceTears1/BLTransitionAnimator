//
//  TarBarMainVC.h
//  翻页效果
//
//  Created by 冰泪 on 2017/6/20.
//  Copyright © 2017年 冰泪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TarBarMainVC : UITabBarController

@end

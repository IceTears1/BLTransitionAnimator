//
//  WMFooldView.h
//  WMPageController
//
//  Created by Mark on 15/7/13.
//  Copyright (c) 2015年 yq. All rights reserved.
//

#import "WMProgressView.h"

@interface WMFooldView : WMProgressView
@property (nonatomic, assign) BOOL hollow;
@end

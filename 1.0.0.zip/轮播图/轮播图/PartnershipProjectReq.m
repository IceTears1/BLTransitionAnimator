//
//  PartnershipProjectReq.m
//  轮播图
//
//  Created by 冰泪 on 2017/4/14.
//  Copyright © 2017年 冰泪. All rights reserved.
//

#import "PartnershipProjectReq.h"

@implementation PartnershipProjectReq

@end

//
//  CustomPartnershipPageController.h
//  轮播图
//
//  Created by 冰泪 on 2017/4/14.
//  Copyright © 2017年 冰泪. All rights reserved.
//

#import "WMPageController.h"

@interface CustomPartnerPageController : WMPageController

@end
